package com.example.mp280;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.hardware.usb.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final int PICK_FILE = 10;
    private TextView status;
    private UsbManager usbManager;
    private UsbDeviceConnection connection;
    private UsbEndpoint outEndpoint;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        usbManager = (UsbManager)getSystemService(USB_SERVICE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(32, 40, 32, 32);

        TextView title = new TextView(this);
        title.setText("PRABHUPRITAM SINGH\nA4 → MP-280 LITE");
        title.setTextSize(22); title.setGravity(Gravity.CENTER);
        box.addView(title);

        TextView info = new TextView(this);
        info.setText("\nSelect an A4 PDF or image. The app converts it to 58 mm thermal format and prints through USB OTG.\n");
        info.setTextSize(16); box.addView(info);

        Button connect = new Button(this); connect.setText("1. CONNECT USB PRINTER");
        box.addView(connect);
        connect.setOnClickListener(v -> connectPrinter());

        Button select = new Button(this); select.setText("2. SELECT A4 PDF / IMAGE");
        box.addView(select);
        select.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("*/*");
            i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/pdf","image/*"});
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, PICK_FILE);
        });

        status = new TextView(this); status.setText("\nStatus: Not connected");
        status.setTextSize(15); box.addView(status);

        setContentView(box);
    }

    private void connectPrinter() {
        HashMap<String, UsbDevice> list = usbManager.getDeviceList();
        if (list.isEmpty()) { status.setText("No USB device found. Connect printer with a USB-OTG adapter/cable."); return; }

        for (UsbDevice d : list.values()) {
            for (int i=0;i<d.getInterfaceCount();i++) {
                UsbInterface inf=d.getInterface(i);
                for(int j=0;j<inf.getEndpointCount();j++) {
                    UsbEndpoint ep=inf.getEndpoint(j);
                    if(ep.getType()==UsbConstants.USB_ENDPOINT_XFER_BULK &&
                       ep.getDirection()==UsbConstants.USB_DIR_OUT) {
                        if(!usbManager.hasPermission(d)) {
                            PendingIntent pi = PendingIntent.getBroadcast(this, 0,
                                new Intent("MP280_USB_PERMISSION"),
                                PendingIntent.FLAG_IMMUTABLE);
                            IntentFilter f=new IntentFilter("MP280_USB_PERMISSION");
                            registerReceiver(new BroadcastReceiver(){
                                public void onReceive(Context c, Intent in){
                                    if(usbManager.hasPermission(d)) openUsb(d, inf, ep);
                                }
                            }, f, RECEIVER_NOT_EXPORTED);
                            usbManager.requestPermission(d, pi);
                        } else openUsb(d, inf, ep);
                        return;
                    }
                }
            }
        }
        status.setText("USB device found, but no bulk OUT printer endpoint was found.");
    }

    private void openUsb(UsbDevice d, UsbInterface inf, UsbEndpoint ep) {
        connection=usbManager.openDevice(d);
        if(connection==null){status.setText("Could not open printer.");return;}
        if(!connection.claimInterface(inf,true)){status.setText("Could not claim USB printer interface.");return;}
        outEndpoint=ep;
        status.setText("Status: Printer connected ✓");
    }

    @Override protected void onActivityResult(int r,int c,Intent data){
        super.onActivityResult(r,c,data);
        if(r==PICK_FILE && c==RESULT_OK && data!=null){
            try {
                Uri u=data.getData();
                if(u.toString().toLowerCase().endsWith(".pdf") ||
                   "application/pdf".equals(getContentResolver().getType(u))) {
                    printPdf(u);
                } else {
                    Bitmap b=BitmapFactory.decodeStream(getContentResolver().openInputStream(u));
                    if(b!=null) printBitmap(b);
                }
            } catch(Exception e){ status.setText("Error: "+e.getMessage()); }
        }
    }

    private void printPdf(Uri uri) throws Exception {
        if(outEndpoint==null) throw new IOException("Connect the printer first.");
        ParcelFileDescriptor pfd=getContentResolver().openFileDescriptor(uri,"r");
        PdfRenderer pdf=new PdfRenderer(pfd);
        for(int n=0;n<pdf.getPageCount();n++){
            PdfRenderer.Page page=pdf.openPage(n);
            int w=384;
            int h=Math.max(1,(int)((float)page.getHeight()/page.getWidth()*w));
            Bitmap bm=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
            bm.eraseColor(Color.WHITE);
            page.render(bm,null,null,PdfRenderer.Page.RENDER_MODE_FOR_PRINT);
            page.close();
            sendBitmapEscPos(bm);
            bm.recycle();
            send(new byte[]{0x1D,0x56,0x00}); // cut if supported
        }
        pdf.close(); pfd.close();
        status.setText("Printed successfully ✓");
    }

    private void printBitmap(Bitmap src) throws Exception {
        if(outEndpoint==null) throw new IOException("Connect the printer first.");
        int w=384;
        int h=Math.max(1,(int)((float)src.getHeight()/src.getWidth()*w));
        Bitmap bm=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        Canvas c=new Canvas(bm); c.drawColor(Color.WHITE);
        Paint p=new Paint(Paint.FILTER_BITMAP_FLAG);
        c.drawBitmap(src,null,new Rect(0,0,w,h),p);
        sendBitmapEscPos(bm);
        send(new byte[]{0x1D,0x56,0x00});
        bm.recycle(); src.recycle();
        status.setText("Printed successfully ✓");
    }

    private void sendBitmapEscPos(Bitmap b) throws Exception {
        // Initialize and center
        send(new byte[]{0x1B,0x40});
        send(new byte[]{0x1B,0x61,0x01});
        // Header
        send(("PRABHUPRITAM SINGH\n").getBytes("CP437"));
        send(new byte[]{0x1B,0x61,0x00});

        int width=b.getWidth(), height=b.getHeight();
        int bytesPerRow=(width+7)/8;
        byte[] cmd=new byte[8+bytesPerRow*height];
        cmd[0]=0x1D; cmd[1]=0x76; cmd[2]=0x30; cmd[3]=0x00;
        cmd[4]=(byte)(bytesPerRow & 0xff); cmd[5]=(byte)((bytesPerRow>>8)&0xff);
        cmd[6]=(byte)(height & 0xff); cmd[7]=(byte)((height>>8)&0xff);

        for(int y=0;y<height;y++){
            for(int x=0;x<width;x++){
                int pix=b.getPixel(x,y);
                int gray=(Color.red(pix)+Color.green(pix)+Color.blue(pix))/3;
                if(gray<180) cmd[8+y*bytesPerRow+(x>>3)] |= (byte)(0x80>>(x&7));
            }
        }
        // Send in manageable chunks because USB buffers vary.
        int pos=0;
        while(pos<cmd.length){
            int len=Math.min(4096,cmd.length-pos);
            byte[] chunk=Arrays.copyOfRange(cmd,pos,pos+len);
            send(chunk); pos+=len;
        }
        send(new byte[]{0x0A,0x0A,0x0A});
    }

    private void send(byte[] data) throws IOException {
        if(connection==null || outEndpoint==null) throw new IOException("Printer not connected.");
        int sent=connection.bulkTransfer(outEndpoint,data, data.length, 10000);
        if(sent<0) throw new IOException("USB print transfer failed.");
    }

    @Override protected void onDestroy(){
        if(connection!=null){try{connection.close();}catch(Exception ignored){}}
        super.onDestroy();
    }
}
